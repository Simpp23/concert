<!-- Content -->
<div class="container mt-3 m-border text-center">
    <h2>Welcome to PHP-DB Web : NATTWAT</h2>
    <div class="d-grid gap-2">

        <a href="insertDataIndex.php" class="btn btn-success">Concert Tickets</a>
        <a href="" class="btn btn-primary">Insert DB with fix data</a>
        <a href="" class="btn btn-primary">Import Connect_DB & Insert Data with SQL</a>
        <a href="" class="btn btn-primary">Insert Data with Form by exec</a>
        <a href="" class="btn btn-primary">Insert Data with SQL by Prepared Statement=> :</a>
        <a href="" class="btn btn-primary">Insert Data with SQL by Prepared Statement=> ?</a>
        <a href="" class="btn btn-primary">Insert Data with Form by PDO</a>
        <a href="" class="btn btn-primary">View Student Data</a>
    </div>
</div>
<!-- End Content -->